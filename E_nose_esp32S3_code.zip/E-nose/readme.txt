视频讲解链接：


主控和气味传感器使用资料：https://www.dfrobot.com.cn/index.php


edgeimpulse对应项目链接，请clone一份到自己的项目中使用：
饮料：https://studio.edgeimpulse.com/studio/515565/
芒果：https://studio.edgeimpulse.com/studio/514886/


edgeimpulse平台使用资料：https://docs.edgeimpulse.com/docs/readme/for-beginners

edgeimpulse平台串口转发器资料：https://docs.edgeimpulse.com/docs/tools/edge-impulse-cli



